const views = Array.from(document.querySelectorAll(".screen"));
const navItems = Array.from(document.querySelectorAll(".nav-item"));
const bestiaryGrid = document.getElementById("bestiaryGrid");
const searchInput = document.getElementById("creatureSearch");
const filterButtons = Array.from(document.querySelectorAll("[data-filter]"));
const themeList = document.getElementById("themeList");
const loreTimeline = document.getElementById("loreTimeline");
const notesField = document.getElementById("sessionNotes");
const saveNotesBtn = document.getElementById("saveNotes");
const clearNotesBtn = document.getElementById("clearNotes");
const densityButtons = Array.from(document.querySelectorAll("[data-density]"));

const creatures = [
  {
    name: "Пепельный волк",
    type: "wild",
    tag: "Стая на границе леса",
    description: "Серебристая шерсть пахнет золой, а следы исчезают до рассвета.",
    danger: "Угроза: средняя"
  },
  {
    name: "Костяной сир",
    type: "undead",
    tag: "Служитель усыпальниц",
    description: "Говорит шёпотом из-под шлема и собирает имена павших в кости.",
    danger: "Угроза: высокая"
  },
  {
    name: "Лунная виверна",
    type: "arcane",
    tag: "Тварь древних пиков",
    description: "Её чешуя отражает небо, которого нет, а дыхание светится холодом.",
    danger: "Угроза: легендарная"
  },
  {
    name: "Моховой тролль",
    type: "wild",
    tag: "Старые мосты и ущелья",
    description: "Питается корнями и камнем, пробуждаясь после долгих дождей.",
    danger: "Угроза: высокая"
  },
  {
    name: "Серафим тени",
    type: "arcane",
    tag: "Небесная ошибка",
    description: "Появляется там, где магия нарушает древний обет молчания.",
    danger: "Угроза: неизвестная"
  },
  {
    name: "Праховик",
    type: "undead",
    tag: "Пустые курганы",
    description: "Оставляет за собой сухой пепел, будто выгорает само воспоминание.",
    danger: "Угроза: средняя"
  }
];

const lore = [
  {
    category: "История",
    items: [
      "Эпоха Туманов: мир скрыт за вечной дымкой, а границы королевств зависят от костров путников.",
      "Падение Башни Севера: старая крепость раскололась надвое, когда артефактный колокол прозвучал без звонаря."
    ]
  },
  {
    category: "Народы",
    items: [
      "Кочевники кромки леса чтят знаки ветра и не называют волков по имени.",
      "Чернильные писцы хранят родословные на свитках, пропитанных пеплом."
    ]
  },
  {
    category: "Государства",
    items: [
      "Серебряный Дом держит северные дороги и требует плату не монетой, а клятвой.",
      "Княжество Трёх Башен правит через совет магистров и старые печати."
    ]
  },
  {
    category: "Поселения",
    items: [
      "Лесная Слобода стоит на костяных мостках и закрывает ставни до заката.",
      "Село Каменных Колодцев живёт вокруг источника, который, говорят, помнит имена умерших."
    ]
  },
  {
    category: "Разное",
    items: [
      "Клятва Чернильного Совета запрещает открывать имена мёртвых до окончания зимы.",
      "Возвращение Драконьих Писцов подарило первые карты, где реки помечены рунами."
    ]
  }
];

const themes = [
  {
    id: "ember",
    label: "Тлеющий уголь",
    note: "Тёплый янтарный свет и пепельный фон.",
    vars: {
      "--bg": "#0f0d0d",
      "--panel": "rgba(31, 24, 19, 0.9)",
      "--accent": "#d39a57",
      "--accent-2": "#7f6a53",
      "--text": "#f6e8d8",
      "--muted": "#c0a98e",
      "--line": "rgba(211, 154, 87, 0.18)",
      "--sheet-tint": "rgba(214, 180, 120, 0.12)",
      "--sheet-tint-2": "rgba(94, 77, 54, 0.24)",
      "--sheet-border": "rgba(225, 193, 137, 0.12)",
      "--sheet-inner": "rgba(225, 193, 137, 0.07)",
      "--sheet-fill": "rgba(44, 35, 26, 0.98)",
      "--sheet-fill-2": "rgba(22, 17, 13, 0.98)",
      "--sheet-cell": "rgba(10, 9, 12, 0.3)"
    }
  },
  {
    id: "moon",
    label: "Лунный туман",
    note: "Сталь, туман и холодный свет.",
    vars: {
      "--bg": "#0c1014",
      "--panel": "rgba(18, 25, 31, 0.9)",
      "--accent": "#88a8b7",
      "--accent-2": "#5d7580",
      "--text": "#ecf3f5",
      "--muted": "#9eb0b9",
      "--line": "rgba(136, 168, 183, 0.18)",
      "--sheet-tint": "rgba(136, 168, 183, 0.12)",
      "--sheet-tint-2": "rgba(93, 117, 128, 0.22)",
      "--sheet-border": "rgba(136, 168, 183, 0.12)",
      "--sheet-inner": "rgba(136, 168, 183, 0.08)",
      "--sheet-fill": "rgba(18, 25, 31, 0.98)",
      "--sheet-fill-2": "rgba(10, 16, 20, 0.98)",
      "--sheet-cell": "rgba(8, 12, 16, 0.34)"
    }
  },
  {
    id: "obsidian",
    label: "Обсидиановая ночь",
    note: "Глубокий мрак и золотые руны.",
    vars: {
      "--bg": "#09090d",
      "--panel": "rgba(19, 18, 26, 0.92)",
      "--accent": "#c49b63",
      "--accent-2": "#6e7d83",
      "--text": "#f1e8dc",
      "--muted": "#ab9b87",
      "--line": "rgba(196, 155, 99, 0.16)",
      "--sheet-tint": "rgba(196, 155, 99, 0.12)",
      "--sheet-tint-2": "rgba(110, 125, 131, 0.20)",
      "--sheet-border": "rgba(196, 155, 99, 0.12)",
      "--sheet-inner": "rgba(196, 155, 99, 0.07)",
      "--sheet-fill": "rgba(38, 30, 24, 0.98)",
      "--sheet-fill-2": "rgba(18, 16, 24, 0.98)",
      "--sheet-cell": "rgba(12, 10, 16, 0.32)"
    }
  }
];

const state = {
  view: "bestiary",
  filter: "all",
  theme: localStorage.getItem("ferelden-theme") || "ember",
  density: localStorage.getItem("ferelden-density") || "compact"
};

function setView(view) {
  state.view = view;
  views.forEach((section) => {
    section.classList.toggle("is-active", section.dataset.view === view);
  });
  navItems.forEach((button) => {
    button.classList.toggle("is-active", button.dataset.target === view);
  });
}

function renderBestiary() {
  const query = searchInput.value.trim().toLowerCase();
  const creaturesToShow = creatures.filter((creature) => {
    const matchesFilter = state.filter === "all" || creature.type === state.filter;
    const matchesQuery =
      creature.name.toLowerCase().includes(query) ||
      creature.description.toLowerCase().includes(query) ||
      creature.tag.toLowerCase().includes(query);
    return matchesFilter && matchesQuery;
  });

  bestiaryGrid.innerHTML = creaturesToShow
    .map(
      (creature) => `
        <article class="card">
          <div class="card__top">
            <div>
              <div class="card__type">${typeLabel(creature.type)}</div>
              <h3>${creature.name}</h3>
            </div>
            <span class="card__tag">${creature.danger}</span>
          </div>
          <p>${creature.description}</p>
          <div class="meta-row">
            <span>${creature.tag}</span>
            <span>${state.density === "dense" ? "Подробное досье" : "Краткая запись"}</span>
          </div>
        </article>
      `
    )
    .join("");
}

function typeLabel(type) {
  switch (type) {
    case "undead":
      return "Нежить";
    case "wild":
      return "Дикие";
    case "arcane":
      return "Магические";
    default:
      return type;
  }
}

function renderLore() {
  loreTimeline.innerHTML = lore
    .map(
      (entry) => `
        <section class="lore-group">
          <div class="lore-group__head">
            <strong>${entry.category}</strong>
            <span>${entry.items.length} записи</span>
          </div>
          <ul class="lore-list">
            ${entry.items.map((item) => `<li>${item}</li>`).join("")}
          </ul>
        </section>
      `
    )
    .join("");
}

function applyTheme(themeId) {
  const theme = themes.find((item) => item.id === themeId) || themes[0];
  state.theme = theme.id;
  Object.entries(theme.vars).forEach(([key, value]) => {
    document.documentElement.style.setProperty(key, value);
  });
  localStorage.setItem("ferelden-theme", theme.id);
  updateThemeButtons();
}

function updateThemeButtons() {
  Array.from(themeList.querySelectorAll(".theme-swatch")).forEach((button) => {
    button.classList.toggle("is-active", button.dataset.theme === state.theme);
  });
}

function renderThemes() {
  themeList.innerHTML = themes
    .map(
      (theme) => `
        <button class="theme-swatch" data-theme="${theme.id}">
          ${theme.label}
          <small>${theme.note}</small>
        </button>
      `
    )
    .join("");

  themeList.querySelectorAll("[data-theme]").forEach((button) => {
    button.addEventListener("click", () => applyTheme(button.dataset.theme));
  });
  updateThemeButtons();
}

function updateDensity() {
  densityButtons.forEach((button) => {
    button.classList.toggle("is-active", button.dataset.density === state.density);
  });
  localStorage.setItem("ferelden-density", state.density);
  renderBestiary();
}

function loadNotes() {
  notesField.value = localStorage.getItem("ferelden-notes") || "";
}

function saveNotes() {
  localStorage.setItem("ferelden-notes", notesField.value);
  saveNotesBtn.textContent = "Сохранено";
  window.setTimeout(() => {
    saveNotesBtn.textContent = "Сохранить";
  }, 1000);
}

function clearNotes() {
  notesField.value = "";
  localStorage.removeItem("ferelden-notes");
}

navItems.forEach((button) => {
  button.addEventListener("click", () => setView(button.dataset.target));
});

filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    state.filter = button.dataset.filter;
    filterButtons.forEach((item) => item.classList.toggle("is-active", item === button));
    renderBestiary();
  });
});

searchInput.addEventListener("input", renderBestiary);

densityButtons.forEach((button) => {
  button.addEventListener("click", () => {
    state.density = button.dataset.density;
    updateDensity();
  });
});

saveNotesBtn.addEventListener("click", saveNotes);
clearNotesBtn.addEventListener("click", clearNotes);

renderBestiary();
renderLore();
renderThemes();
applyTheme(state.theme);
loadNotes();
updateDensity();
setView(state.view);
